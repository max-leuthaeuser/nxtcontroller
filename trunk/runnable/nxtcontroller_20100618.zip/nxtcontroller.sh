#!/bin/sh
java -client -Djava.library.path=lib -jar nxtcontroller.jar
